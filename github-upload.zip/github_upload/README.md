# NCERT-RAG-Eval

Curriculum-aligned benchmark for evaluating retrieval strategies (BM25, dense
FAISS, and Hybrid RRF) in Retrieval-Augmented Generation against official NCERT
Physics textbooks. Companion repository for the paper "Benchmarking Retrieval
Strategies for Curriculum-Aligned Retrieval-Augmented Generation Using
NCERT-RAG-Eval Physics Textbooks".

## Contents
- `code/harness_v2.py` - retrieval pipeline (BM25 via rank_bm25, FAISS over
  all-MiniLM-L6-v2 embeddings, Hybrid via Reciprocal Rank Fusion) and the
  Recall / Precision / Faithfulness evaluation used for every result table.
- `code/build_new_questions.py`, `code/build_new_paraphrases.py` - construction
  scripts for the Light / Electricity / Magnetism question and paraphrase sets.
- `data/` - the 237-chunk five-chapter corpus (`chunks_v2.json`), the 88
  gold-annotated benchmark questions (`questions_v2.json`), and the 40
  paraphrased variants (`paraphrase_v2.json`).
- `results/` - JSON and CSV exports of every experiment reported in the paper
  (overall performance, top-k sweep, corpus growth, paraphrase robustness).
- `figures_src/` - scripts that generate every figure in the paper.
- `generation_pilot/` - the RAG vs. closed-book generation pilot: runner
  script, model outputs, and per-question correctness scoring.

## Reproducing the retrieval results
```bash
pip install rank_bm25 sentence-transformers faiss-cpu numpy
python - << 'PY'
from code.harness_v2 import CHUNKS, QUESTIONS, build_indices, evaluate
state = build_indices(CHUNKS)
print(evaluate(state, QUESTIONS, k=3))
PY
```
The sentence-embedding model defaults to downloading
`sentence-transformers/all-MiniLM-L6-v2`; set `MINILM_PATH` to a local copy to
run offline.

## Generation pilot
`generation_pilot/generate_answers.py` calls the NVIDIA NIM API
(`meta/llama-3.1-8b-instruct`). Set `NVIDIA_API_KEY` in your environment; the
key is never stored in this repository. `answers_output.json` and
`generation_scoring.json` contain the generations and manual correctness
judgments reported in the paper.

## Data licensing
NCERT textbook content is used under NCERT's open-access distribution of its
textbooks for educational purposes. This repository stores derived chunk text
solely to enable reproduction of the benchmark.
