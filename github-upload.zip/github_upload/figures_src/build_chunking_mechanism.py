import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import json

chunks = json.load(open('data/chunks_v2.json'))
c1 = [c for c in chunks if c['id'] == 'motion_c9_001'][0]['text'].split()

spans = [
    ('motion_c9_000', 0, 200, '#4C72B0'),
    ('motion_c9_001', 150, 350, '#55A868'),
    ('motion_c9_002', 300, 500, '#C44E52'),
]

# Wide aspect ratio so the figure fills a full-width page slot with large,
# legible text rather than being scaled down with wasted whitespace.
fig, ax = plt.subplots(figsize=(15, 4.6))

bar_h = 0.62
y_positions = [2.3, 1.25, 0.2]

for (cid, start, end, color), y in zip(spans, y_positions):
    ax.add_patch(mpatches.Rectangle((start, y), end - start, bar_h,
                                     linewidth=2.0, edgecolor='#222222', facecolor=color, alpha=0.9))
    ax.text(start + (end - start) / 2, y + bar_h / 2, cid, ha='center', va='center',
            color='white', fontsize=18, fontweight='bold')

overlap_regions = [(150, 200), (300, 350)]
for start, end in overlap_regions:
    ax.add_patch(mpatches.Rectangle((start, -0.15), end - start, 2.95, facecolor='#FFD54F',
                                     alpha=0.30, edgecolor='#B8860B', linewidth=1.2, zorder=0))
    ax.text((start + end) / 2, -0.55, '50-word\noverlap', ha='center', va='top', fontsize=13,
            color='#7a5c00', fontweight='bold')

ax.set_xlim(-15, 515)
ax.set_ylim(-1.1, 3.15)
ax.set_xticks([0, 150, 200, 300, 350, 500])
ax.tick_params(axis='x', labelsize=14)
ax.set_xlabel('Word position in Motion chapter source text', fontsize=15)
ax.set_yticks([])
for spine in ['top', 'right', 'left']:
    ax.spines[spine].set_visible(False)
ax.spines['bottom'].set_linewidth(1.5)

plt.tight_layout()
plt.savefig('figures_src/chunking_mechanism.pdf', bbox_inches='tight', dpi=300)
plt.savefig('figures_src/chunking_mechanism_preview.png', bbox_inches='tight', dpi=200)
print("done")
