import graphviz

g = graphviz.Digraph('system_pipeline', format='pdf')
g.attr(rankdir='LR', splines='ortho', nodesep='0.4', ranksep='0.55', bgcolor='white')
g.attr('node', fontname='Helvetica', fontsize='15', style='filled', shape='box',
       penwidth='1.2', margin='0.3,0.22')
g.attr('edge', fontname='Helvetica', fontsize='11', penwidth='1.6', color='#555555', arrowsize='0.8')

NAVY = '#2B4570'
BLUE = '#E8F0FE'
GREEN = '#E6F4EA'
ORANGE = '#FFF3E0'
PURPLE = '#F3E8FD'
GREY_BORDER = '#9AA5B1'

with g.subgraph(name='cluster_staging') as c:
    c.attr(label='Staging (offline, once)', fontname='Helvetica-Bold', fontsize='16',
           style='filled', fillcolor='#FAFBFC', color=GREY_BORDER, penwidth='1.4',
           labelloc='t', margin='18')
    c.node('pdf', 'NCERT PDFs\n(5 chapters, Class 9-10)', fillcolor=GREEN, color='#34A853')
    c.node('extract', 'Text Extraction\n& Cleaning', fillcolor=BLUE, color=NAVY)
    c.node('chunk', 'Chunking\n(200-word window,\n50-word overlap)', fillcolor=BLUE, color=NAVY)
    c.node('index', 'BM25 Index +\nFAISS Index\n(all-MiniLM-L6-v2)', fillcolor='#D2E3FC', color=NAVY)
    c.edge('pdf', 'extract')
    c.edge('extract', 'chunk')
    c.edge('chunk', 'index')

with g.subgraph(name='cluster_inference') as c:
    c.attr(label='Inference (per query)', fontname='Helvetica-Bold', fontsize='16',
           style='filled', fillcolor='#FAFBFC', color=GREY_BORDER, penwidth='1.4',
           labelloc='t', margin='18')
    c.node('query', 'User Query', fillcolor=GREEN, color='#34A853')
    c.node('retrieve', 'BM25 / FAISS /\nHybrid (RRF)\nRetrieval', fillcolor=BLUE, color=NAVY)
    c.node('chunks', 'Top-k Retrieved\nNCERT Chunks', fillcolor='#D2E3FC', color=NAVY)
    c.node('gen', 'LLM Generation\n(RAG-grounded)', fillcolor=PURPLE, color='#7B1FA2')
    c.node('eval', 'Evaluation:\nRecall / Precision /\nFaithfulness / Correctness', fillcolor=ORANGE, color='#E65100')
    c.edge('query', 'retrieve')
    c.edge('retrieve', 'chunks')
    c.edge('chunks', 'gen')
    c.edge('gen', 'eval')

g.edge('index', 'query', style='dashed', color='#888888', constraint='false')
g.edge('chunks', 'eval', style='dashed', color='#888888', constraint='false')

g.render('figures_src/system_pipeline', cleanup=True)
print("done")
