import json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams['font.family'] = 'DejaVu Sans'

para = json.load(open('results/paraphrase_results_v2.json'))
methods = ['BM25', 'FAISS', 'Hybrid']

fig, ax = plt.subplots(figsize=(6.5, 4.8))
fig.patch.set_facecolor('white')
x = range(len(methods))
orig_recall = [para['original_matched'][m]['Recall'] for m in methods]
para_recall = [para['paraphrased'][m]['Recall'] for m in methods]
w = 0.35
ax.bar([i - w/2 for i in x], orig_recall, width=w, label='Original questions', color='#1F618D', edgecolor='#0B3D5C', linewidth=1.2)
ax.bar([i + w/2 for i in x], para_recall, width=w, label='Paraphrased questions', color='#D68910', edgecolor='#9C6500', linewidth=1.2)
ax.set_xticks(list(x))
ax.set_xticklabels(methods, fontsize=13)
ax.set_ylabel('Recall', fontsize=14)
ax.tick_params(labelsize=12.5)
ax.set_ylim(0, 1.05)
ax.set_facecolor('#FAFAFA')
ax.grid(alpha=0.5, color='#DDDDDD', linewidth=0.8, axis='y')
ax.set_axisbelow(True)
for spine in ['top', 'right']:
    ax.spines[spine].set_visible(False)
for spine in ['left', 'bottom']:
    ax.spines[spine].set_linewidth(1.3)
    ax.spines[spine].set_color('#666666')
ax.legend(fontsize=12.5, frameon=True, framealpha=0.9)
plt.tight_layout()
plt.savefig('figures_src/paraphrase_precision_line.png', dpi=200, bbox_inches='tight')
plt.close()
print("done")
