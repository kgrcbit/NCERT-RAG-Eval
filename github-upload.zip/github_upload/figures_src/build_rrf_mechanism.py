import graphviz

g = graphviz.Digraph('rrf_mechanism', format='pdf')
g.attr(rankdir='LR', splines='line', nodesep='0.5', ranksep='0.9', bgcolor='white')
g.attr('node', fontname='Helvetica', fontsize='14', shape='plaintext')
g.attr('edge', fontname='Helvetica', fontsize='12', penwidth='1.6', color='#666666', arrowsize='0.9')

NAVY = '#2B4570'
BLUE = '#E8F0FE'
GREEN = '#E6F4EA'
ORANGE = '#FFF3E0'
GOLD_HL = '#FFE08A'

TITLE_PT = "15"
CELL_PT = "14"
NOTE_PT = "12"

bm25_rows = [
    ("1", "motion_c9_042", False),
    ("2", "motion_c9_012", False),
    ("3", "motion_c9_021", False),
    ("4", "electricity_c10_048", False),
    ("5", "motion_c9_009", True),
]
faiss_rows = [
    ("1", "motion_c9_010", True),
    ("2", "motion_c9_017", False),
    ("3", "motion_c9_012", False),
    ("4", "motion_c9_011", False),
    ("5", "motion_c9_009", True),
]
hybrid_rows = [
    ("1", "motion_c9_012", "0.03200", False),
    ("2", "motion_c9_009", "0.03077", True),
    ("3", "motion_c9_021", "0.03058", False),
    ("4", "motion_c9_017", "0.03021", False),
    ("5", "motion_c9_041", "0.02765", False),
]

def cell(text, bg="white", bold=False, pt=CELL_PT):
    inner = f"<B>{text}</B>" if bold else text
    return f'<TD BGCOLOR="{bg}" CELLPADDING="6"><FONT POINT-SIZE="{pt}">{inner}</FONT></TD>'

def make_table(title, rows, ncols, header_color):
    rows_html = ""
    if ncols == 2:
        rows_html += "<TR>" + cell("Rank", header_color, True) + cell("Chunk ID", header_color, True) + "</TR>"
        for rank, cid, is_gold in rows:
            bg = GOLD_HL if is_gold else "white"
            rows_html += "<TR>" + cell(rank, bg) + cell(cid, bg) + "</TR>"
    else:
        rows_html += "<TR>" + cell("Rank", header_color, True) + cell("Chunk ID", header_color, True) + cell("RRF Score", header_color, True) + "</TR>"
        for rank, cid, score, is_gold in rows:
            bg = GOLD_HL if is_gold else "white"
            rows_html += "<TR>" + cell(rank, bg) + cell(cid, bg) + cell(score, bg) + "</TR>"
    title_cell = f'<TD COLSPAN="{ncols}" BGCOLOR="{NAVY}" CELLPADDING="6"><FONT COLOR="white" POINT-SIZE="{TITLE_PT}"><B>{title}</B></FONT></TD>'
    return f'''<
<TABLE BORDER="2" CELLBORDER="1" CELLSPACING="0">
<TR>{title_cell}</TR>
{rows_html}
</TABLE>>'''

g.node('question', '<<TABLE BORDER="2" CELLBORDER="0" CELLSPACING="0" BGCOLOR="' + GREEN + '">'
       f'<TR><TD CELLPADDING="6"><FONT POINT-SIZE="{TITLE_PT}"><B>Query (q09)</B></FONT></TD></TR>'
       f'<TR><TD CELLPADDING="6"><FONT POINT-SIZE="{CELL_PT}">"What is speed, and<BR/>what is its SI unit?"</FONT></TD></TR>'
       '</TABLE>>', shape='plaintext')

g.node('bm25', make_table('BM25 Ranking', bm25_rows, 2, '#5B7FB5'))
g.node('faiss', make_table('FAISS Ranking', faiss_rows, 2, '#5B7FB5'))
g.node('hybrid', make_table('Hybrid (RRF) Result', hybrid_rows, 3, '#E65100'))

g.node('formula', '<<TABLE BORDER="2" CELLBORDER="0" CELLSPACING="0" BGCOLOR="' + ORANGE + '">'
       f'<TR><TD CELLPADDING="6"><FONT POINT-SIZE="{TITLE_PT}"><B>Reciprocal Rank Fusion</B></FONT></TD></TR>'
       f'<TR><TD CELLPADDING="8"><FONT POINT-SIZE="{CELL_PT}">RRF(c) = &#931;<SUB>m</SUB> 1 / (60 + rank<SUB>m</SUB>(c) + 1)</FONT></TD></TR>'
       f'<TR><TD CELLPADDING="6"><FONT POINT-SIZE="{NOTE_PT}">e.g. motion_c9_012: BM25 rank 2, FAISS rank 3</FONT></TD></TR>'
       f'<TR><TD CELLPADDING="6"><FONT POINT-SIZE="{NOTE_PT}">= 1/62 + 1/63 = 0.03200 (highest combined score)</FONT></TD></TR>'
       '</TABLE>>', shape='plaintext')

g.edge('question', 'bm25')
g.edge('question', 'faiss')
g.edge('bm25', 'formula')
g.edge('faiss', 'formula')
g.edge('formula', 'hybrid')

g.render('figures_src/rrf_mechanism', cleanup=True)
print("done")
