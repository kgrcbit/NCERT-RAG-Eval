import json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams['font.family'] = 'DejaVu Sans'

topk = json.load(open('results/topk_v2.json'))
methods = ['BM25', 'FAISS', 'Hybrid']
colors = {'BM25': '#C0392B', 'FAISS': '#E0218A', 'Hybrid': '#117864'}
markers = {'BM25': 'o', 'FAISS': 's', 'Hybrid': '^'}
ks = [1, 3, 5, 10]

def style_axis(ax):
    ax.set_facecolor('#FAFAFA')
    ax.grid(alpha=0.5, color='#DDDDDD', linewidth=0.8)
    ax.set_axisbelow(True)
    for spine in ['top', 'right']:
        ax.spines[spine].set_visible(False)
    for spine in ['left', 'bottom']:
        ax.spines[spine].set_linewidth(1.3)
        ax.spines[spine].set_color('#666666')

for metric, fname in [('Precision', 'precision_vs_k.png'),
                       ('Recall', 'recall_vs_k.png'),
                       ('Faithfulness', 'faithfulness_vs_k.png')]:
    fig, ax = plt.subplots(figsize=(6.5, 4.8))
    fig.patch.set_facecolor('white')
    for m in methods:
        vals = [topk[str(k)][m][metric] for k in ks]
        ax.plot(ks, vals, marker=markers[m], color=colors[m], label=m, linewidth=2.8,
                markersize=10, markerfacecolor='white', markeredgewidth=2.2, markeredgecolor=colors[m])
    ax.set_xlabel('k (chunks retrieved)', fontsize=14)
    ax.set_ylabel(metric, fontsize=14)
    ax.set_xticks(ks)
    ax.tick_params(labelsize=12.5)
    ax.set_ylim(0, 1.05)
    style_axis(ax)
    ax.legend(fontsize=12.5, frameon=True, framealpha=0.9, loc='best')
    plt.tight_layout()
    plt.savefig(f'figures_src/{fname}', dpi=200, bbox_inches='tight')
    plt.close()

print("done")
