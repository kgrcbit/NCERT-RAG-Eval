import graphviz

g = graphviz.Digraph('eval_architecture', format='pdf')
g.attr(rankdir='TB', splines='ortho', nodesep='0.7', ranksep='0.22', bgcolor='white')
g.attr('node', fontname='Helvetica', fontsize='15', style='filled', shape='box',
       penwidth='1.2', margin='0.5,0.15')
g.attr('edge', fontname='Helvetica', fontsize='11', penwidth='1.6', color='#555555', arrowsize='0.8')

NAVY = '#2B4570'
BLUE = '#E8F0FE'
GREEN = '#E6F4EA'
ORANGE = '#FFF3E0'
PURPLE = '#F3E8FD'
YELLOW = '#FFF9DB'
GREY_BORDER = '#9AA5B1'

# ---- Retrieval evaluation cluster ----
with g.subgraph(name='cluster_retrieval') as c:
    c.attr(label='Retrieval Evaluation', fontname='Helvetica-Bold', fontsize='16',
           style='filled', fillcolor='#FAFBFC', color=GREY_BORDER, penwidth='1.4',
           labelloc='t', margin='16')
    c.node('q', 'Benchmark\nQuestion', fillcolor=GREEN, color='#34A853')
    c.node('bm25', 'BM25', fillcolor=BLUE, color=NAVY)
    c.node('faiss', 'FAISS', fillcolor=BLUE, color=NAVY)
    c.node('hybrid', 'Hybrid (RRF)', fillcolor=BLUE, color=NAVY)
    c.node('topk', 'Top-k Retrieved\nChunks', fillcolor='#D2E3FC', color=NAVY)
    c.node('gold', 'Gold NCERT\nChunks', fillcolor=YELLOW, color='#B8860B')
    c.node('recall', 'Recall', fillcolor=ORANGE, color='#E65100')
    c.node('precision', 'Precision', fillcolor=ORANGE, color='#E65100')
    c.node('faith', 'Faithfulness', fillcolor=ORANGE, color='#E65100')

    c.edge('q', 'bm25')
    c.edge('q', 'faiss')
    c.edge('q', 'hybrid')
    c.edge('bm25', 'topk')
    c.edge('faiss', 'topk')
    c.edge('hybrid', 'topk')
    c.edge('topk', 'recall')
    c.edge('topk', 'precision')
    c.edge('topk', 'faith')
    c.edge('gold', 'recall')
    c.edge('gold', 'precision')
    c.edge('gold', 'faith')

# ---- Generation pilot cluster ----
with g.subgraph(name='cluster_generation') as c:
    c.attr(label='Generation Pilot', fontname='Helvetica-Bold', fontsize='16',
           style='filled', fillcolor='#FAFBFC', color=GREY_BORDER, penwidth='1.4',
           labelloc='t', margin='16')
    c.node('genq', 'Question +\nTop-3 Chunks', fillcolor=GREEN, color='#34A853')
    c.node('cbq', 'Question Only', fillcolor=GREEN, color='#34A853')
    c.node('rag', 'RAG Generation\n(Llama-3.1-8B)', fillcolor=PURPLE, color='#7B1FA2')
    c.node('cb', 'Closed-book Generation\n(Llama-3.1-8B)', fillcolor=PURPLE, color='#7B1FA2')
    c.node('check', 'Manual Correctness\nCheck vs. Gold', fillcolor=ORANGE, color='#E65100')

    c.edge('genq', 'rag')
    c.edge('cbq', 'cb')
    c.edge('rag', 'check')
    c.edge('cb', 'check')

# Cross-cluster connections (dashed, showing shared inputs)
g.edge('topk', 'genq', style='dashed', constraint='false', color='#888888')
g.edge('gold', 'check', style='dashed', constraint='false', color='#888888')

g.render('figures_src/eval_architecture', cleanup=True)
print("done")
