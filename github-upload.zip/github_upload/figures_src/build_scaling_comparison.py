import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json

plt.rcParams['font.family'] = 'DejaVu Sans'

results = json.load(open('results/growth_v2.json'))

fig, axes = plt.subplots(1, 2, figsize=(16, 6.2))
fig.patch.set_facecolor('white')

NAVY = '#1F3A5F'
TEAL = '#0F766E'
GRID_C = '#DDDDDD'

# ---- LEFT: Corpus scaling by chunk duplication ----
ax = axes[0]
ax.set_facecolor('#FAFAFA')
sizes_old = [76, 152, 304, 608]
precision_old = [0.84, 0.44, 0.20, 0.20]
ax.plot(sizes_old, precision_old, marker='o', color=NAVY, linewidth=3, markersize=12,
        markerfacecolor='white', markeredgewidth=2.5, markeredgecolor=NAVY, zorder=3)
ax.fill_between(sizes_old, precision_old, alpha=0.08, color=NAVY)
ax.set_xlabel('Corpus size (chunks)', fontsize=15)
ax.set_ylabel('BM25 Precision', fontsize=15)
ax.set_ylim(0, 1.0)
ax.tick_params(labelsize=13)
ax.grid(alpha=0.5, color=GRID_C, linewidth=0.8)
ax.set_axisbelow(True)
ax.annotate('Same 76 chunks\nduplicated 2x, 4x, 8x', xy=(304, 0.20), xytext=(190, 0.62),
            fontsize=13, color='#333333', fontweight='normal',
            arrowprops=dict(arrowstyle='-|>', color='#666666', alpha=0.8, linewidth=1.8,
                             connectionstyle='arc3,rad=0.15'))
for spine in ['top', 'right']:
    ax.spines[spine].set_visible(False)
for spine in ['left', 'bottom']:
    ax.spines[spine].set_linewidth(1.3)
    ax.spines[spine].set_color('#666666')

# ---- RIGHT: Corpus scaling with distinct chapter content ----
ax2 = axes[1]
ax2.set_facecolor('#FAFAFA')
sizes_new = sorted(int(k) for k in results.keys())
precision_new = [results[str(s)]['BM25']['Precision'] for s in sizes_new]
ax2.plot(sizes_new, precision_new, marker='o', color=TEAL, linewidth=3, markersize=12,
         markerfacecolor='white', markeredgewidth=2.5, markeredgecolor=TEAL, zorder=3)
ax2.fill_between(sizes_new, precision_new, alpha=0.08, color=TEAL)
ax2.set_xlabel('Corpus size (chunks)', fontsize=15)
ax2.set_ylabel('BM25 Precision', fontsize=15)
ax2.set_ylim(0, 1.0)
ax2.tick_params(labelsize=13)
ax2.grid(alpha=0.5, color=GRID_C, linewidth=0.8)
ax2.set_axisbelow(True)
ax2.annotate('207 gold-source chunks\n(4 chapters) + 0/10/20/30\ndistractor chunks', xy=(227, precision_new[2]), xytext=(212, 0.62),
             fontsize=13, color='#333333', fontweight='normal',
             arrowprops=dict(arrowstyle='-|>', color='#666666', alpha=0.8, linewidth=1.8,
                              connectionstyle='arc3,rad=-0.15'))
for spine in ['top', 'right']:
    ax2.spines[spine].set_visible(False)
for spine in ['left', 'bottom']:
    ax2.spines[spine].set_linewidth(1.3)
    ax2.spines[spine].set_color('#666666')

plt.tight_layout()
plt.savefig('figures_src/scaling_comparison.pdf', bbox_inches='tight', dpi=300)
plt.savefig('figures_src/scaling_comparison_preview.png', bbox_inches='tight', dpi=200)
print("done")
