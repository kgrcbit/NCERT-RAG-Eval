import json, os, numpy as np
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer
import faiss

CHUNKS = json.load(open("data/chunks_v2.json"))
QUESTIONS = json.load(open("data/questions_v2.json"))

MODEL_PATH = os.environ.get("MINILM_PATH", "sentence-transformers/all-MiniLM-L6-v2")
_model = None
def get_model():
    global _model
    if _model is None:
        _model = SentenceTransformer(MODEL_PATH)
    return _model

def build_indices(chunks):
    ids = [c["id"] for c in chunks]
    docs = [c["text"] for c in chunks]
    tok = [d.lower().split() for d in docs]
    bm25 = BM25Okapi(tok)
    model = get_model()
    emb = model.encode(docs, show_progress_bar=False)
    index = faiss.IndexFlatL2(emb.shape[1])
    index.add(np.array(emb).astype("float32"))
    return {"ids": ids, "docs": docs, "bm25": bm25, "faiss": index, "model": model}

def bm25_topk(state, query, k):
    scores = state["bm25"].get_scores(query.lower().split())
    order = np.argsort(scores)[::-1][:k]
    return [state["ids"][i] for i in order]

def faiss_topk(state, query, k):
    v = state["model"].encode([query]).astype("float32")
    _, idxs = state["faiss"].search(v, k)
    return [state["ids"][i] for i in idxs[0]]

def hybrid_topk(state, query, k, rrf_k=60):
    pool = min(len(state["ids"]), max(k * 4, 20))
    bm25_ranked = bm25_topk(state, query, pool)
    faiss_ranked = faiss_topk(state, query, pool)
    scores = {}
    for rank, cid in enumerate(bm25_ranked):
        scores[cid] = scores.get(cid, 0.0) + 1.0 / (rrf_k + rank + 1)
    for rank, cid in enumerate(faiss_ranked):
        scores[cid] = scores.get(cid, 0.0) + 1.0 / (rrf_k + rank + 1)
    ranked = sorted(scores.items(), key=lambda x: -x[1])
    return [cid for cid, _ in ranked[:k]]

RETRIEVERS = {"BM25": bm25_topk, "FAISS": faiss_topk, "Hybrid": hybrid_topk}

def evaluate(state, questions, k, methods=("BM25", "FAISS", "Hybrid")):
    results = {}
    for m in methods:
        recalls, precisions, faiths = [], [], []
        for q in questions:
            retrieved = RETRIEVERS[m](state, q["question"], k)
            gold = set(q["gold_chunks"])
            hit = len(gold.intersection(retrieved)) > 0
            recalls.append(1.0 if hit else 0.0)
            precisions.append(len(gold.intersection(retrieved)) / len(retrieved) if retrieved else 0.0)
            faiths.append(1.0 if hit else 0.0)
        results[m] = {
            "Recall": float(np.mean(recalls)),
            "Precision": float(np.mean(precisions)),
            "Faithfulness": float(np.mean(faiths)),
        }
    return results
