import json

LIGHT = [
    ("What are the two laws of reflection of light?", ["light_c10_002"]),
    ("What is the difference between a concave mirror and a convex mirror?", ["light_c10_004", "light_c10_005"]),
    ("What is the centre of curvature of a spherical mirror?", ["light_c10_006"]),
    ("What is the principal axis of a spherical mirror?", ["light_c10_007"]),
    ("What is the principal focus of a concave mirror?", ["light_c10_009"]),
    ("What is the relationship between the radius of curvature and the focal length of a spherical mirror?", ["light_c10_010"]),
    ("State the mirror formula relating object distance, image distance, and focal length.", ["light_c10_025"]),
    ("How is the magnification produced by a spherical mirror defined?", ["light_c10_026", "light_c10_027"]),
    ("A convex mirror used for rear-view has a radius of curvature of 3.00 m; a bus is located 5.00 m from it. Find the position and nature of the image.", ["light_c10_027", "light_c10_028"]),
    ("Why do vehicles prefer a convex mirror as a rear-view mirror?", ["light_c10_023"]),
    ("What are the two laws of refraction of light, and what is Snell's law?", ["light_c10_038"]),
    ("What is the refractive index of a medium, and how is it related to the speed of light in that medium?", ["light_c10_039", "light_c10_040", "light_c10_041"]),
    ("What does it mean for one medium to be optically denser than another?", ["light_c10_041", "light_c10_042"]),
    ("What is a convex lens, and why is it also called a converging lens?", ["light_c10_044"]),
    ("What is the principal focus of a convex lens, and of a concave lens?", ["light_c10_048", "light_c10_049"]),
    ("State the lens formula relating object distance, image distance, and focal length.", ["light_c10_057"]),
    ("How is the magnification produced by a lens defined?", ["light_c10_057", "light_c10_058"]),
    ("What is the power of a lens, and what is its SI unit?", ["light_c10_061", "light_c10_062"]),
    ("A 2.0 cm tall object is placed 15 cm from a convex lens of focal length 10 cm. Find the nature, position, and size of the image.", ["light_c10_059", "light_c10_060"]),
    ("How is the total power of several lenses placed in contact calculated?", ["light_c10_062", "light_c10_063"]),
]

ELECTRICITY = [
    ("What is electric current, and how is it mathematically defined?", ["electricity_c10_001", "electricity_c10_002"]),
    ("What is the SI unit of electric current, and how is one ampere defined?", ["electricity_c10_002"]),
    ("What instrument measures electric current, and how is it connected in a circuit?", ["electricity_c10_003"]),
    ("What is electric potential difference, and how is it defined?", ["electricity_c10_005", "electricity_c10_006"]),
    ("What is the SI unit of potential difference, and how is one volt defined?", ["electricity_c10_006"]),
    ("What instrument measures potential difference, and how is it connected in a circuit?", ["electricity_c10_007"]),
    ("State Ohm's law relating potential difference and current.", ["electricity_c10_011", "electricity_c10_012"]),
    ("What is electrical resistance, and what is its SI unit?", ["electricity_c10_012"]),
    ("What happens to the current through a resistor if its resistance is doubled?", ["electricity_c10_012", "electricity_c10_013"]),
    ("How does the resistance of a conductor depend on its length and area of cross-section?", ["electricity_c10_017"]),
    ("An electric bulb draws current from a 220 V source with filament resistance 1200 ohm. What current does it draw?", ["electricity_c10_019"]),
    ("How is the equivalent resistance of resistors connected in series calculated?", ["electricity_c10_027", "electricity_c10_028"]),
    ("An electric lamp of 20 ohm and a conductor of 4 ohm are connected in series to a 6 V battery. Find the total resistance and current.", ["electricity_c10_028", "electricity_c10_029"]),
    ("How is the equivalent resistance of resistors connected in parallel calculated?", ["electricity_c10_032", "electricity_c10_033"]),
    ("Three resistors of 5, 10, and 30 ohm are connected in parallel to a 12 V battery. Find the current through each resistor and the total current.", ["electricity_c10_033", "electricity_c10_034"]),
    ("What is Joule's law of heating, and what does it say heat produced depends on?", ["electricity_c10_040"]),
    ("100 J of heat is produced each second in a 4 ohm resistor. Find the potential difference across the resistor.", ["electricity_c10_042"]),
    ("What is the formula for electric power in terms of voltage, current, and resistance?", ["electricity_c10_046"]),
    ("What is the commercial unit of electrical energy, and how does it relate to joules?", ["electricity_c10_047"]),
    ("An electric bulb is connected to a 220 V generator and draws a current of 0.50 A. What is the power of the bulb?", ["electricity_c10_047", "electricity_c10_048"]),
]

MAGNETISM = [
    ("What is a magnetic field, and how can it be detected around a bar magnet?", ["magnetism_c10_003"]),
    ("What is the convention for the direction of magnetic field lines around a bar magnet?", ["magnetism_c10_004", "magnetism_c10_005"]),
    ("Why do two magnetic field lines never cross each other?", ["magnetism_c10_005"]),
    ("What does the right-hand thumb rule (Maxwell's corkscrew rule) tell us about the magnetic field around a current-carrying wire?", ["magnetism_c10_014"]),
    ("How does the magnetic field due to a circular loop change as you move from the wire toward the centre of the loop?", ["magnetism_c10_014", "magnetism_c10_015"]),
    ("How does the magnetic field produced by a coil of n turns compare to that of a single turn carrying the same current?", ["magnetism_c10_015", "magnetism_c10_016"]),
    ("What is a solenoid, and how does its magnetic field pattern compare to that of a bar magnet?", ["magnetism_c10_017"]),
    ("What is an electromagnet, and how is it formed using a solenoid?", ["magnetism_c10_017", "magnetism_c10_018"]),
]

def build(prefix, items, start_idx):
    out = []
    for i, (q, gold) in enumerate(items):
        out.append({"id": f"{prefix}{start_idx+i:02d}", "question": q, "gold_chunks": gold})
    return out

all_new_qs = (
    build("nq", LIGHT, 1) +
    build("nq", ELECTRICITY, 21) +
    build("nq", MAGNETISM, 41)
)

json.dump(all_new_qs, open("data/new_questions.json", "w"), indent=1)
print("Total new questions:", len(all_new_qs))
print("Light:", len(LIGHT), "Electricity:", len(ELECTRICITY), "Magnetism:", len(MAGNETISM))
