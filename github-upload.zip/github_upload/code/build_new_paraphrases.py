import json

PARAPHRASES = [
    ("nq01", "How would you state the two rules governing how light reflects off a surface?"),
    ("nq03", "What do we call the point at the centre of a spherical mirror's reflecting surface?"),
    ("nq06", "How are focal length and radius of curvature related for a spherical mirror?"),
    ("nq07", "Write down the formula connecting object distance, image distance, and focal length for a mirror."),
    ("nq11", "What are Snell's two laws describing how light bends when it passes between media?"),
    ("nq12", "How does a medium's refractive index relate to how fast light travels through it?"),
    ("nq14", "Why is a convex lens sometimes called a converging lens?"),
    ("nq16", "Give the formula relating object distance, image distance, and focal length for a lens."),
    ("nq18", "In what unit is a lens's power measured, and how is power defined?"),
    ("nq21", "What is the mathematical definition of electric current?"),
    ("nq24", "How is potential difference between two points defined?"),
    ("nq27", "What relationship does Ohm's law describe between voltage and current?"),
    ("nq30", "What factors determine how the resistance of a wire depends on its length and thickness?"),
    ("nq32", "How do you compute the total resistance when resistors are wired in series?"),
    ("nq34", "What's the formula for combining resistances connected in parallel?"),
    ("nq36", "According to Joule's law, what does the heat generated in a resistor depend on?"),
    ("nq38", "How is electrical power expressed in terms of voltage, current, and resistance?"),
    ("nq41", "How can you tell there's a magnetic field around a bar magnet?"),
    ("nq44", "What does the right-hand thumb rule tell you about a current-carrying wire's magnetic field?"),
    ("nq47", "What is a solenoid, and how does it behave like a bar magnet?"),
]

base = {q["id"]: q for q in json.load(open("data/new_questions.json"))}
out = []
for qid, para_text in PARAPHRASES:
    out.append({"id": qid + "_p", "question": para_text, "gold_chunks": base[qid]["gold_chunks"]})

json.dump(out, open("data/new_paraphrase_questions.json", "w"), indent=1)
print("Wrote", len(out), "new paraphrased questions")
