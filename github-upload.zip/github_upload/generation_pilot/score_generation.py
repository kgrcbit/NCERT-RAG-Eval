import json

# Manual correctness scoring (Claude, cross-checked against gold NCERT chunk
# content and physics correctness). "incorrect" = factually wrong, incoherent,
# or off-topic relative to what was asked. Notes explain the specific failure.
# q37's closed-book condition failed with an API rate-limit error, not a
# genuine answer, and is excluded from closed-book scoring (N=39 for CB).

SCORING = {
    "q01": {"rag": "correct", "cb": "correct", "note": "Retrieval miss, but both answers give the correct general definition of motion."},
    "q02": {"rag": "correct", "cb": "correct", "note": ""},
    "q03": {"rag": "correct", "cb": "correct", "note": ""},
    "q04": {"rag": "incorrect", "cb": "correct", "note": "RAG answers 'what is speed' instead of 'what is distance travelled' -- picked the wrong retrieved excerpt to answer from despite the correct chunk (005) being in the top-3."},
    "q05": {"rag": "incorrect", "cb": "correct", "note": "RAG answer is incoherent: strings together fragments ('the magnitude of displacement') without ever stating what displacement actually is. Caused by a mid-sentence chunk boundary."},
    "q06": {"rag": "correct", "cb": "correct", "note": "CB substitutes its own example (10km walk) for the textbook's 60km example; still physically correct."},
    "q07": {"rag": "incorrect", "cb": "correct", "note": "Retrieval miss pulled acceleration-related chunks. RAG then defines uniform MOTION in terms of constant VELOCITY/uniform ACCELERATION (conflating two different concepts) -- a clear case of misleading retrieved context causing a wrong answer. CB, with no such distraction, gives the correct constant-speed definition."},
    "q08": {"rag": "correct", "cb": "correct", "note": ""},
    "q09": {"rag": "correct", "cb": "correct", "note": ""},
    "q10": {"rag": "correct", "cb": "correct", "note": ""},
    "q11": {"rag": "correct", "cb": "correct", "note": ""},
    "q12": {"rag": "correct", "cb": "correct", "note": "Both compute 5.33 m/s correctly."},
    "q13": {"rag": "correct", "cb": "correct", "note": ""},
    "q14": {"rag": "correct", "cb": "correct", "note": ""},
    "q15": {"rag": "correct", "cb": "correct", "note": "CB answer correct but left in non-SI units (m/min) rather than converting to m/s."},
    "q16": {"rag": "correct", "cb": "correct", "note": ""},
    "q17": {"rag": "correct", "cb": "correct", "note": "Both compute 50 km/h correctly."},
    "q18": {"rag": "correct", "cb": "correct", "note": ""},
    "q19": {"rag": "correct", "cb": "correct", "note": ""},
    "q20": {"rag": "correct", "cb": "borderline", "note": "CB's phrasing ('positive when the object is moving in the direction of the velocity') is circular/confused; RAG's phrasing correctly ties acceleration's sign to its direction relative to velocity."},
    "q21": {"rag": "correct", "cb": "correct", "note": "CB substitutes its own example (car at 2 m/s^2) instead of the textbook's freely-falling-body example; still physically valid."},
    "q22": {"rag": "incorrect", "cb": "correct", "note": "RAG makes an arithmetic error: (4-6)/5 stated as -0.8 m/s^2, should be -0.4 m/s^2 -- notably, the correct value (-0.4) is visible in the RAG condition's own gold/retrieved text, so this is a computational hallucination that contradicts its own context. CB computes -0.4 correctly."},
    "q23": {"rag": "correct", "cb": "correct", "note": ""},
    "q24": {"rag": "correct", "cb": "correct", "note": ""},
    "q25": {"rag": "correct", "cb": "correct", "note": ""},
    "q26": {"rag": "correct", "cb": "correct", "note": ""},
    "q27": {"rag": "correct", "cb": "correct", "note": ""},
    "q28": {"rag": "borderline", "cb": "correct", "note": "RAG visibly self-corrects a wrong third equation (writes a=(v^2-u^2)/2t, flags it as wrong, restates as /2s) -- ends correct but shows a mid-generation error. CB states all three equations cleanly and correctly on the first try."},
    "q29": {"rag": "correct", "cb": "correct", "note": ""},
    "q30": {"rag": "correct", "cb": "incorrect", "note": "RAG correctly computes a=1/15 m/s^2, s=3km, matching the textbook worked example exactly. CB makes a decimal-point/order-of-magnitude error: computes a=0.67 m/s^2 (should be ~0.067) and s=3x10^4 m (should be 3x10^3 m, i.e. 3km) -- roughly 10x too large on both."},
    "q31": {"rag": "correct", "cb": "correct", "note": "Both reach 12m; CB's reasoning implicitly (and incorrectly) assumes the car starts from rest rather than braking from some initial speed, but the final number is numerically right for these specific values."},
    "q32": {"rag": "correct", "cb": "correct", "note": "Both compute a=1 m/s^2, s=37.5m correctly."},
    "q33": {"rag": "correct", "cb": "correct", "note": "Retrieval miss, but both answers correctly explain centripetal/directional acceleration in uniform circular motion from general knowledge."},
    "q34": {"rag": "incorrect", "cb": "correct", "note": "RAG states v=pi*r/t (missing the factor of 2). The retrieved source chunk itself has a PDF-extraction artifact rendering '2*pi*r' as 'pi2 r', and the model appears to have dropped the '2' as a result -- a hallucination directly caused by corrupted source text. CB, using its own parametric knowledge, correctly states v=2*pi*r/t."},
    "q35": {"rag": "correct", "cb": "correct", "note": ""},
    "q36": {"rag": "borderline", "cb": "correct", "note": "Retrieval miss (pulled equations-of-motion chunks instead of the chapter summary). RAG appropriately hedges ('the chapter does not contain a direct summary') rather than fabricating one -- good faithful behavior -- but then restates the same flawed third equation seen in q28 (divides by t instead of s). CB gives a clean, correct summary from its own knowledge."},
    "q37": {"rag": "correct", "cb": "error", "note": "CB call failed with a 429 rate-limit error, not a genuine answer -- excluded from CB scoring denominator."},
    "q38": {"rag": "correct", "cb": "correct", "note": "Retrieval hit; both correctly identify the method (circumference/time) without being asked to compute a final number."},
    "q39": {"rag": "correct", "cb": "correct", "note": "Retrieval miss, but both give the correct equation of motion from general knowledge."},
    "q40": {"rag": "correct", "cb": "correct", "note": "Retrieval miss, but both give the correct equation of motion from general knowledge."},
}

d = json.load(open("generation_pilot/answers_output.json"))
gold_hit = {}
for q in d:
    gold_hit[q["id"]] = bool(set(q["gold_chunks"]) & set(q["retrieved_chunk_ids"]))

out = []
for q in d:
    s = SCORING[q["id"]]
    out.append({
        "id": q["id"],
        "retrieval_hit": gold_hit[q["id"]],
        "rag_score": s["rag"],
        "cb_score": s["cb"],
        "note": s["note"],
    })

json.dump(out, open("generation_pilot/generation_scoring.json", "w"), indent=1)

# Summary stats
rag_correct = sum(1 for o in out if o["rag_score"] == "correct")
rag_borderline = sum(1 for o in out if o["rag_score"] == "borderline")
rag_incorrect = sum(1 for o in out if o["rag_score"] == "incorrect")
cb_valid = [o for o in out if o["cb_score"] != "error"]
cb_correct = sum(1 for o in cb_valid if o["cb_score"] == "correct")
cb_borderline = sum(1 for o in cb_valid if o["cb_score"] == "borderline")
cb_incorrect = sum(1 for o in cb_valid if o["cb_score"] == "incorrect")

print("RAG: correct=%d borderline=%d incorrect=%d / 40 (accuracy=%.3f, treating borderline as correct)" %
      (rag_correct, rag_borderline, rag_incorrect, (rag_correct+rag_borderline)/40))
print("CB:  correct=%d borderline=%d incorrect=%d / %d valid (accuracy=%.3f, treating borderline as correct)" %
      (cb_correct, cb_borderline, cb_incorrect, len(cb_valid), (cb_correct+cb_borderline)/len(cb_valid)))

hit_qs = [o for o in out if o["retrieval_hit"]]
miss_qs = [o for o in out if not o["retrieval_hit"]]
rag_incorrect_on_hits = sum(1 for o in hit_qs if o["rag_score"] == "incorrect")
rag_incorrect_on_misses = sum(1 for o in miss_qs if o["rag_score"] == "incorrect")
print("RAG incorrect on retrieval HITS: %d / %d" % (rag_incorrect_on_hits, len(hit_qs)))
print("RAG incorrect on retrieval MISSES: %d / %d" % (rag_incorrect_on_misses, len(miss_qs)))
