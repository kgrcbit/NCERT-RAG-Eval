# Generation-level hallucination experiment for NCERT-RAG-Eval.
#
# For each of the 40 benchmark questions, generates TWO answers from the
# same LLM: (1) "rag" -- with the real Hybrid-retrieved top-3 NCERT chunks
# as context, and (2) "closed_book" -- no context, parametric knowledge only.
#
# Saves everything to answers_output.json. Send that file back and we'll
# score faithfulness/hallucination against the gold NCERT evidence.
#
# Needs questions_with_context.json in the same folder/session.

import json
import os
import time
from openai import OpenAI

MODEL = "meta/llama-3.1-8b-instruct"
INPUT_FILE = "questions_with_context.json"
OUTPUT_FILE = "answers_output.json"
TEMPERATURE = 0.2
MAX_TOKENS = 300

NVIDIA_API_KEY = os.environ.get("NVIDIA_API_KEY", "")  # set via environment variable

SYSTEM_PROMPT = (
    "You are an AI tutor helping a Class 9 student with NCERT Physics "
    "(the Motion chapter). Answer the student's question directly and "
    "concisely, in 2-4 sentences. If a numeric answer or formula is "
    "requested, state it clearly."
)

RAG_INSTRUCTIONS = (
    "Use ONLY the following textbook excerpts to answer the question. "
    "If the excerpts do not contain the answer, say so rather than guessing."
)


def build_client():
    return OpenAI(base_url="https://integrate.api.nvidia.com/v1", api_key=NVIDIA_API_KEY)


def generate(client, system_prompt, user_prompt):
    resp = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=TEMPERATURE,
        max_tokens=MAX_TOKENS,
    )
    return resp.choices[0].message.content.strip()


def build_rag_prompt(question, retrieved_texts):
    lines = []
    lines.append(RAG_INSTRUCTIONS)
    lines.append("")
    lines.append("Textbook excerpts:")
    for j, text in enumerate(retrieved_texts):
        lines.append("[Excerpt " + str(j + 1) + "] " + text)
    lines.append("")
    lines.append("Question: " + question)
    return "\n".join(lines)


def main():
    client = build_client()
    questions = json.load(open(INPUT_FILE))
    results = []

    for i, q in enumerate(questions):
        print("[" + str(i + 1) + "/" + str(len(questions)) + "] " + q["id"] + ": " + q["question"][:60])

        rag_prompt = build_rag_prompt(q["question"], q["retrieved_chunk_texts"])
        closed_prompt = "Question: " + q["question"]

        try:
            rag_answer = generate(client, SYSTEM_PROMPT, rag_prompt)
        except Exception as e:
            rag_answer = "[ERROR: " + str(e) + "]"
        time.sleep(0.5)

        try:
            closed_book_answer = generate(client, SYSTEM_PROMPT, closed_prompt)
        except Exception as e:
            closed_book_answer = "[ERROR: " + str(e) + "]"
        time.sleep(0.5)

        results.append({
            "id": q["id"],
            "question": q["question"],
            "gold_chunks": q["gold_chunks"],
            "gold_chunk_texts": q["gold_chunk_texts"],
            "retrieved_chunk_ids": q["retrieved_chunk_ids"],
            "model": MODEL,
            "rag_answer": rag_answer,
            "closed_book_answer": closed_book_answer,
        })

        json.dump(results, open(OUTPUT_FILE, "w"), indent=1)

    print("")
    print("Done. Wrote " + str(len(results)) + " results to " + OUTPUT_FILE)
    print("Send this file back and we will score it for the paper.")


if __name__ == "__main__":
    main()
