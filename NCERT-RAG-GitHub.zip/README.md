# NCERT-RAG-Eval
A Benchmark for Evaluating Retrieval-Augmented Generation on NCERT Textbooks

NCERT-RAG-Eval is a research benchmark for evaluating how well Retrieval-Augmented
Generation (RAG) systems retrieve and use authoritative NCERT textbook content.

The framework supports BM25, Dense (FAISS + SBERT), and Hybrid retrieval pipelines
and evaluates them using Recall, Precision, and Faithfulness metrics.

Repository Structure:
- data/        : NCERT PDFs, corpus, chunks, and benchmark questions
- scripts/     : End-to-end pipeline for building and evaluating RAG
- results/     : Evaluation outputs
- figures/     : Plots for the paper

To run:
python scripts/run_full_pipeline.py
