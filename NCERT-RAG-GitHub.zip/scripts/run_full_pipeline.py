import os
os.system('python scripts/pdf_to_text.py')
os.system('python scripts/chunk_text.py')
os.system('python scripts/build_indices.py')
os.system('python scripts/run_retrieval.py')