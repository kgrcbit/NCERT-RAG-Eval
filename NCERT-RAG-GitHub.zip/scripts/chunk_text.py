import os
IN='data/corpus/ncert_corpus.txt'; OUT='data/chunks/chunks.txt'
os.makedirs('data/chunks',exist_ok=True)
w=open(IN,'r',encoding='utf-8').read().split()
cs,ov=200,50; i=0; ch=[]
while i<len(w):
    ch.append(' '.join(w[i:i+cs])); i+=cs-ov
open(OUT,'w',encoding='utf-8').write('\n\n'.join(ch))
print('Chunks',len(ch))