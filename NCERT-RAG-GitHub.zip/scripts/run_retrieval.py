import pickle,faiss,numpy as np
from sentence_transformers import SentenceTransformer
docs=[d.strip() for d in open('data/chunks/chunks.txt','r',encoding='utf-8').read().split('\n\n') if d.strip()]
bm25=pickle.load(open('data/chunks/bm25.pkl','rb'))
index=faiss.read_index('data/chunks/faiss.index')
model=SentenceTransformer('all-MiniLM-L6-v2')
qs=[q.strip() for q in open('data/questions/questions.txt') if q.strip()]
k=3
for q in qs:
    print('\nQ:',q)
    sc=bm25.get_scores(q.lower().split()); b=np.argsort(sc)[::-1][:k]
    print('BM25:'); [print('-',docs[i][:120]) for i in b]
    v=model.encode([q]).astype('float32'); _,f=index.search(v,k)
    print('FAISS:'); [print('-',docs[i][:120]) for i in f[0]]