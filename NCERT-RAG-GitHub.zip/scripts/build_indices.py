import pickle,faiss,numpy as np
from sentence_transformers import SentenceTransformer
from rank_bm25 import BM25Okapi
docs=[d.strip() for d in open('data/chunks/chunks.txt','r',encoding='utf-8').read().split('\n\n') if d.strip()]
tok=[d.lower().split() for d in docs]
bm25=BM25Okapi(tok); pickle.dump(bm25,open('data/chunks/bm25.pkl','wb'))
model=SentenceTransformer('all-MiniLM-L6-v2')
emb=model.encode(docs)
index=faiss.IndexFlatL2(emb.shape[1]); index.add(np.array(emb).astype('float32'))
faiss.write_index(index,'data/chunks/faiss.index')
print('Indices built')