import os,re
from PyPDF2 import PdfReader
PDF_DIR='data/raw_pdfs'; OUT='data/corpus/ncert_corpus.txt'
os.makedirs('data/corpus',exist_ok=True)
def clean(t):
    t=t.replace('\n',' ')
    t=re.sub(r'\s+',' ',t)
    return t.strip()
all=[]
for f in os.listdir(PDF_DIR):
    if f.endswith('.pdf'):
        r=PdfReader(os.path.join(PDF_DIR,f))
        for p in r.pages:
            t=p.extract_text()
            if t: all.append(clean(t))
open(OUT,'w',encoding='utf-8').write('\n'.join(all))
print('Saved',OUT)